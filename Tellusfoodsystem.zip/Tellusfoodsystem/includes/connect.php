<?php
session_start();
$servername = "localhost";
$server_user = "root";
$server_pass = "";
$dbname = "tellusfood";
$fname = $_SESSION['fname'];
$lname = $_SESSION['lname'];
$role = $_SESSION['role'];
$photo = $_SESSION['photo'];
$con = new mysqli($servername, $server_user, $server_pass, $dbname);
?>