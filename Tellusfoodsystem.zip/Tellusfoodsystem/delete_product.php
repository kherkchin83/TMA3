<?php
include 'includes/connect.php';

	$id = $_GET['product'];

	$sql="delete from items where productid='$id'";
	$con->query($sql);

	header('location:product_maint.php');
?>