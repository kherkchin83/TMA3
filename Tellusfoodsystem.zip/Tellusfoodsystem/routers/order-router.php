<?php
include '../includes/connect.php';

$total = 0;
$address = htmlspecialchars($_POST['address']);
$payment_type = $_POST['payment_type'];
$total = $_POST['total'];
$cash_amt = $_POST['cash_amt'];
$restid=$_GET['restaurant'];
$user_id = $_SESSION['user_id'];

	$sql = "INSERT INTO orders (restaurant_id, customer_id, address, payment_type, grand_total, cash_amt) VALUES ($restid, $user_id, '$address','$payment_type', $total, $cash_amt)";
	if ($con->query($sql) === TRUE){
		$order_id =  $con->insert_id;
		foreach ($_POST as $key => $value)
		{
			if(is_numeric($key)){
			$result = mysqli_query($con, "SELECT * FROM items WHERE productid = $key");
			while($row = mysqli_fetch_array($result))
			{
				$unitprice = $row['price'];
			}
				$price = round($value*$unitprice,2);
			$sql = "INSERT INTO order_details (order_id, item_id, quantity, price) VALUES ($order_id, $key, $value, $price)";
			$con->query($sql) === TRUE;		
			}
		}
			header("location: ../restaurant_menu.php");
	}
?>