<?php
include '../includes/connect.php';
$success=false;

$userid = $_POST['userid'];
$email = $_POST['email'];
$password = $_POST['password'];

$result = mysqli_query($con, "SELECT * FROM users WHERE userid='$userid' AND email='$email' AND not deleted;");
while($row = mysqli_fetch_array($result))
{
	$success = true;
	$user_id = $row['id'];
	$fname = $row['fname'];
	$lname = $row['lname'];
	$role= $row['role'];
}
if($success == true)
{	
$sql = "UPDATE users SET password='$password' WHERE id = $user_id;";
if($con->query($sql)==true){
		session_start();
		$_SESSION['customer_sid']=session_id();
		$_SESSION['user_id'] = $user_id;
		$_SESSION['role'] = $role;
		$_SESSION['fname'] = $fname;	
		$_SESSION['lname'] = $lname;			
		header("location: ../restaurant_menu.php");
	}
	else
	{
		header("location: ../login.php");
	}
}
	else
	{
		header("location: ../login.php");
	}
?>