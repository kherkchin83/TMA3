<?php
include '../includes/connect.php';
$status = $_POST['status'];
$id = $_POST['id'];

$sql = "UPDATE orders SET status='$status', deleted = substr('$status',1,1) WHERE id=$id;";
$con->query($sql);

header("location: ../restaurant_orders.php");
?>