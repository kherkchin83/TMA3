<?php
include '../includes/connect.php';
$user_id = $_SESSION['user_id'];

$fname = htmlspecialchars($_POST['fname']);
$lname = htmlspecialchars($_POST['lname']);
$phone = $_POST['phone'];
$email = htmlspecialchars($_POST['email']);
$password =  htmlspecialchars($_POST['password']);
$address = htmlspecialchars($_POST['address']);

	$fileinfo=PATHINFO($_FILES["photo"]["name"]);

	if(empty($fileinfo['filename'])){
		$location="upload/biz_photo/noimage.jpg";
	}
	else{
	$newFilename=$fileinfo['filename'] ."_". time() . "." . $fileinfo['extension'];
	move_uploaded_file($_FILES["photo"]["tmp_name"],"../upload/biz_photo/" . $newFilename);
	$location="upload/biz_photo/" . $newFilename;
	}

$sql = "UPDATE users SET lname = '$lname', password='$password', contact=$phone, email='$email', address='$address', photo='$location' WHERE id = $user_id;";

if($con->query($sql)==true){
	$_SESSION['fname'] = $fname;
	$_SESSION['lname'] = $lname;
}
header("location: ../bizprofile.php");
?>