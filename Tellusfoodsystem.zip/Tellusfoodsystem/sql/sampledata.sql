--
-- Dumping data for table `items`
--
INSERT INTO `items` (`restaurant_id`, `productid`, `productname`, `productdesc`, `price`, `deleted`, `photo`) VALUES
(88, 47, 'Salmon Sushi', 'Norway Salmon Sushi', '4.00', 0, 'upload/SalmonSushi_1571660718.jpg'),
(88, 48, 'Tuna Sushi', 'Fresh Tuna Sushi', '4.00', 0, 'upload/TunaSushi_1571660790.jpg'),
(88, 49, 'Amaebi Mentai Sushi', 'Special Sauce on top of baked prawn sushi', '12.00', 0, 'upload/PrawnSushi_1571660886.jpg'),
(88, 50, 'Fresh Osyter (6Pcs)', '6 pieces of fresh osyter', '30.00', 0, 'upload/Osyter_1571660969.jpg'),
(6, 24, 'Teriyaki Chicken Don', 'Teriyaki Chicken Don', '15.90', 0, 'upload/chicken-teriyaki don_1571837880.jpg'),
(6, 25, 'Chicken Karaage Don', 'Chicken Karaage Don', '15.90', 0, 'upload/Chicken Karaage Don_1571837958.jpg'),
(6, 26, 'Garlic Fried Rice', 'Garlic Fried Rice', '12.90', 0, 'upload/Garlic fried rice_1571837982.jpg'),
(6, 27, 'Gyoza', '6 pcs', '12.90', 0, 'upload/Gyoza_1571838003.jpg'),
(6, 28, 'Miso Ramen', 'with 1 egg, 2 chashu', '23.90', 0, 'upload/Miso ramen_1571838035.jpg'),
(7, 29, 'Nasi Lemak', 'Nasi Lemak Biasa', '10.90', 0, 'upload/Nasi Lemak_1571838371.jpg'),
(7, 30, 'Nasi Lemak Ayam Rendang', 'Nasi Lemak Ayam Rendang', '13.90', 0, 'upload/nasi lemak ayam redang_1571838394.jpg'),
(7, 31, 'Nasi Kerabu Kelantan', 'Nasi Kerabu Kelantan', '14.90', 0, 'upload/Nasi Kerabu_1571838418.jpg'),
(7, 32, 'Nasi Goreng Paprik', 'Nasi Goreng Paprik', '12.90', 0, 'upload/nasi goreng paprik_1571838455.jpg'),
(7, 33, 'Nasi Goreng Pattaya', 'Nasi Goreng Pattaya', '11.90', 0, 'upload/nasi-goreng-pattaya_1571838481.jpg'),
(7, 34, 'Nasi Goreng Cina', 'Nasi Goreng Cina', '10.90', 0, 'upload/nasi goreng cima_1571838517.jpeg'),
(8, 35, 'Pad Thai', 'Pad Thai', '12.90', 0, 'upload/Pad Thai_1571838794.jpg'),
(8, 36, 'Tom Yam Seafood', '1 pax', '17.90', 0, 'upload/tom yam seafood_1571838819.jpg'),
(8, 37, 'Green Curry Chicken', '1 pax ', '18.90', 0, 'upload/green curry chicken_1571838849.jpg'),
(8, 38, 'Mango Salad', 'Imported mango from Thailand', '15.90', 0, 'upload/mango salad_1571838882.jpg'),
(8, 39, 'Papaya Salad', 'Imported grade A papaya from Thailand', '16.90', 0, 'upload/papaya salad_1571838927.jpg'),
(8, 40, 'Thai Fish Cake', '6 pcs', '16.90', 0, 'upload/Thai-Fish-Cakes-w-Dipping-Sauce-WEB_1571838960.jpg');

--
-- Dumping data for table `users`
--
INSERT INTO `users` (`id`, `role`, `userid`, `fname`, `lname`, `contact`, `email`, `password`, `address`, `verified`, `deleted`, `photo`) VALUES
(88, 'Partner', '999999Z', 'Sushi Prince', 'Selling Sushi and Drinks', 60123456789, 'SushiPrince@Yahoo.com', '222222', 'Wisma Texchem, Lot 111 &amp; 112, Jalan Subang 5,\r\nTaman Perindustrian Subang, 47610,\r\nSubang Jaya, Selangor', 1, 0, 'upload/biz_photo/images_1571660203.png'),
(99, 'Consumer', '880808075678', 'Johnathan', 'Lee', 60889988998, 'JLee@Hotmail.com', '111111', 'Level 15, UOA Corporate Tower', 1, 0, 'upload/user_photo/avatar_1571662516.jpg'),
(6, 'Partner', 'JAPAN01', 'OYISHIII CAFE', 'Oyishiiiiiii de cafe desu', 60606112233, 'oyishii@makan.com', '123456', 'L10-11 Sun Geo,\r\nSelangor', 1, 0, 'upload/biz_photo/japan_1571838212.jpg'),
(7, 'Partner', 'MAMAK01', 'MASAKAN BEST IN TOWN', 'We cook the best local food in TOWWWWN', 60991919191, 'bestintown@cafe.com', '123456', 'Lorong Mamak E-A-E-A', 1, 0, 'upload/biz_photo/logo_1571838671.png'),
(8, 'Partner', 'THAIL01', 'AROY MAK MAK', 'We cook the Thai food in TOWWWWN', 6099191919, 'aroymakmak@cafe.com', '123456', '', 1, 0, 'upload/biz_photo/logo_1571839133.jpg'),
(9, 'Consumer', '890706075321', 'LENG ', 'ZAI', 601122334455, 'imlengzai@wahaha.com', '123456', 'Kampung Baru', 1, 0, 'upload/user_photo/boy_1571839351.png');


--
-- Dumping data for table `orders`
--
INSERT INTO `orders` (`id`, `restaurant_id`, `customer_id`, `address`, `date`, `payment_type`, `grand_total`, `cash_amt`, `status`, `deleted`) VALUES
(19, 88, 99, 'Level 15, UOA Corporate Tower', '2019-10-21 21:10:41', 'Cash On Delivery', 168, 168, '5. Order Completed', 5),
(20, 88, 99, 'Level 15, UOA Corporate Tower', '2019-10-21 21:34:59', 'Cash On Delivery', 16, 16, '4. Order Delivering', 4),
(21, 88, 99, 'Level 15, UOA Corporate Tower', '2019-10-21 21:56:05', 'Dine In', 12, 12, '4. Table Serving', 4),
(22, 6, 99, 'Level 15, UOA Corporate Tower', '2019-10-23 22:35:12', 'Dine In', 31.8, 32, '1. Order Created', 0),
(23, 8, 9, 'Kampung Baru', '2019-10-23 22:36:54', 'Cash On Delivery', 12.9, 13, '2. Order Confirmed', 2),
(24, 7, 9, 'Kampung Baru', '2019-10-23 22:37:38', 'Cash On Delivery', 10.9, 11, '1. Order Created', 0),
(25, 6, 9, 'Kampung Baru', '2019-10-23 22:37:54', 'Dine In', 47.7, 48, '1. Order Created', 0);


--
-- Dumping data for table `order_details`
--
INSERT INTO `order_details` (`id`, `order_id`, `item_id`, `quantity`, `price`) VALUES
(35, 19, 47, 1, 4),
(36, 19, 48, 2, 8),
(37, 19, 49, 3, 36),
(38, 19, 50, 4, 120),
(39, 20, 47, 2, 8),
(40, 20, 48, 2, 8),
(41, 21, 47, 1, 4),
(42, 21, 48, 2, 8),
(43, 22, 24, 2, 31.8),
(44, 23, 35, 1, 12.9),
(45, 24, 29, 1, 10.9),
(46, 25, 24, 1, 15.9),
(47, 25, 25, 2, 31.8);




